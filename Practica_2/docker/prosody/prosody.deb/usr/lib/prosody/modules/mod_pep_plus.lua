module:log("error", "mod_pep_plus has been renamed to mod_pep, please update your config file. Auto-loading mod_pep...");
module:depends("pep");
